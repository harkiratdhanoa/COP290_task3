package com.example.myapplication;

public class DataExtractor
{
    public int get(String s)
    {
        return 1;
    }
    public int getG(String s)
    {
        return 1;
    }
}
