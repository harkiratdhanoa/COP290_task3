package com.example.myapplication;

public class NotEnoughMoney extends Exception{};

